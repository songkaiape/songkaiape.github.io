title: about
date: 2016-02-14 11:17:55
---
## Road Untravel

## Destiny is the only thing i don't believe